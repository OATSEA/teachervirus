# tv-admin-osfm
Open Source File Manager for Teacher Virus Administation

based on the single file file manager script from
http://www.osfilemanager.com/

To Do:
* enable file navigation from root folder (currently uses home folder of folder of script and modifications to folder home don't work)
* replace security check with Teacher Virus security check (pattern lock)

Future:
* Multi-lingual interface
* Address Folder Security issues (needs chmod of 777?) 
